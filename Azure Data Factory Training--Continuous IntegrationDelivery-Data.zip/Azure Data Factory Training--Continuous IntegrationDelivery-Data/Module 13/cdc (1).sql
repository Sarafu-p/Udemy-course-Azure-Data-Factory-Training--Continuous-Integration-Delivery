
	Use adventureworksdb;

	CREATE TABLE dbo.tbl_products_source (
	  product_id INT PRIMARY KEY,
	  product_name VARCHAR(50),
	  category VARCHAR(20),
	  price DECIMAL(10,2)
	);


	CREATE TABLE dbo.tbl_products_sink (
	  product_id INT PRIMARY KEY,
	  product_name VARCHAR(50),
	  category VARCHAR(20),
	  price DECIMAL(10,2)
	);





	select * from dbo.tbl_products_source
	select * from dbo.tbl_products_sink 



































INSERT INTO dbo.tbl_products_source (product_id, product_name, category, price)
VALUES (1001, 'Apple iPhone', 'Electronics', 999),
       (1002, 'Samsung Galaxy', 'Electronics', 899),
       (1003, 'Sony Bravia', 'TV & Home', 1499),
       (1004, 'Bose Headphones', 'Audio', 299),
       (1005, 'HP Spectre', 'Computers', 1399),
       (1006, 'Nike Air Max', 'Footwear', 129),
       (1007, 'Levi''s Jeans', 'Clothing', 89),
       (1008, 'Gucci Bag', 'Accessories', 799);

















--Insert New Data


INSERT INTO dbo.tbl_products_source (product_id, product_name, category, price)
VALUES (1009, 'Amazon Kindle', 'Electronics', 129),
       (1010, 'Adidas Ultraboost', 'Footwear', 180),
       (1011, 'Calvin Klein Perfume', 'Beauty', 75.50);


----Update Data
UPDATE dbo.tbl_products_source
SET price = price * 1.05
WHERE category = 'Electronics';



-----Delete our data

DELETE FROM dbo.tbl_products_source
WHERE category = 'Beauty';





















