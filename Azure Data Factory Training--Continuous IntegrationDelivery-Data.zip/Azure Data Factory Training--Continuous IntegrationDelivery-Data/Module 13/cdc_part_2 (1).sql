



	select name , is_cdc_enabled from sys.databases	  
	exec sys.sp_cdc_enable_db



	select name, is_tracked_by_cdc from sys.tables
  
	EXEC sys.sp_cdc_enable_table  
	@source_schema  = N'dbo',  
	@source_name    = N'tbl_products_source',  
	@role_name      = NULL,   
	@supports_net_changes = 1
	GO



	sys.sp_cdc_help_change_data_capture






--- EXEC sys.sp_cdc_disable_db  

EXEC sys.sp_cdc_disable_table  
@source_schema = N'dbo',  
@source_name   =  N'tbl_products_source',  
@capture_instance = 'dbo_tbl_products_source'
GO  
