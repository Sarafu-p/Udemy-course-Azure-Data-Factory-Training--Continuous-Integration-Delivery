
USE [lab-5]

select * from customer;

select * from address;

select * from Sales;

GO
Create table Sales_Details(
Invoice_id int,	
Cust_id	int,Year int,	
Product_id int,	
Product varchar(50),	
Sales decimal
);
go
select * from Sales_Details

INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	1	,	165	,	2019	,	2	,'digital',	522	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	2	,	129	,	2019	,	2	,'digital',	201	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	3	,	141	,	2018	,	3	,'sports items',	561	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	4	,	203	,	2014	,	4	,'home appliances',	335	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	5	,	72	,	2014	,	3	,'sports items',	225	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	6	,	92	,	2015	,	1	,'electronics',	151	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	7	,	56	,	2018	,	4	,'home appliances',	925	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	8	,	116	,	2017	,	3	,'sports items',	808	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	9	,	15	,	2018	,	4	,'home appliances',	791	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	10	,	249	,	2017	,	2	,'digital',	808	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	11	,	168	,	2017	,	3	,'sports items',	848	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	12	,	178	,	2015	,	2	,'digital',	405	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	13	,	101	,	2016	,	4	,'home appliances',	438	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	14	,	5	,	2015	,	4	,'home appliances',	386	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	15	,	42	,	2014	,	3	,'sports items',	185	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	16	,	166	,	2015	,	1	,'electronics',	751	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	17	,	250	,	2018	,	1	,'electronics',	618	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	18	,	239	,	2018	,	3	,'sports items',	200	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	19	,	61	,	2019	,	3	,'sports items',	547	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	20	,	138	,	2014	,	2	,'digital',	287	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	21	,	223	,	2016	,	2	,'digital',	755	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	22	,	81	,	2018	,	2	,'digital',	179	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	23	,	16	,	2014	,	1	,'electronics',	103	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	24	,	119	,	2015	,	3	,'sports items',	721	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	25	,	87	,	2015	,	1	,'electronics',	883	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	26	,	109	,	2016	,	4	,'home appliances',	580	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	27	,	107	,	2018	,	1	,'electronics',	122	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	28	,	180	,	2017	,	2	,'digital',	184	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	29	,	235	,	2016	,	4	,'home appliances',	247	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	30	,	230	,	2015	,	4	,'home appliances',	368	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	31	,	212	,	2016	,	1	,'electronics',	552	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	32	,	221	,	2015	,	2	,'digital',	245	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	33	,	29	,	2016	,	2	,'digital',	185	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	34	,	159	,	2015	,	4	,'home appliances',	646	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	35	,	101	,	2015	,	3	,'sports items',	486	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	36	,	232	,	2018	,	1	,'electronics',	603	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	37	,	126	,	2015	,	4	,'home appliances',	115	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	38	,	149	,	2019	,	2	,'digital',	215	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	39	,	68	,	2018	,	3	,'sports items',	573	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	40	,	173	,	2018	,	3	,'sports items',	324	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	41	,	75	,	2014	,	1	,'electronics',	463	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	42	,	53	,	2016	,	4	,'home appliances',	416	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	43	,	141	,	2017	,	3	,'sports items',	411	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	44	,	228	,	2015	,	4	,'home appliances',	430	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	45	,	87	,	2019	,	1	,'electronics',	129	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	46	,	129	,	2017	,	4	,'home appliances',	335	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	47	,	105	,	2019	,	1	,'electronics',	129	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	48	,	197	,	2019	,	4	,'home appliances',	700	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	49	,	34	,	2015	,	2	,'digital',	315	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	50	,	6	,	2014	,	2	,'digital',	566	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	51	,	244	,	2015	,	1	,'electronics',	908	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	52	,	109	,	2016	,	3	,'sports items',	314	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	53	,	190	,	2018	,	4	,'home appliances',	844	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	54	,	77	,	2017	,	4	,'home appliances',	726	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	55	,	211	,	2017	,	1	,'electronics',	448	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	56	,	48	,	2017	,	3	,'sports items',	744	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	57	,	68	,	2017	,	4	,'home appliances',	309	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	58	,	215	,	2015	,	2	,'digital',	166	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	59	,	161	,	2019	,	1	,'electronics',	177	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	60	,	36	,	2015	,	2	,'digital',	843	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	61	,	172	,	2018	,	2	,'digital',	741	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	62	,	116	,	2016	,	3	,'sports items',	82	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	63	,	66	,	2017	,	4	,'home appliances',	656	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	64	,	193	,	2018	,	4	,'home appliances',	447	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	65	,	167	,	2018	,	3	,'sports items',	150	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	66	,	135	,	2018	,	1	,'electronics',	589	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	67	,	216	,	2016	,	4	,'home appliances',	598	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	68	,	83	,	2014	,	4	,'home appliances',	895	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	69	,	174	,	2017	,	3	,'sports items',	212	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	70	,	115	,	2019	,	4	,'home appliances',	58	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	71	,	49	,	2014	,	1	,'electronics',	761	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	72	,	119	,	2019	,	2	,'digital',	651	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	73	,	232	,	2018	,	3	,'sports items',	150	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	74	,	25	,	2014	,	3	,'sports items',	560	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	75	,	45	,	2016	,	2	,'digital',	808	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	76	,	152	,	2015	,	2	,'digital',	780	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	77	,	97	,	2014	,	3	,'sports items',	463	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	78	,	57	,	2014	,	3	,'sports items',	179	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	79	,	207	,	2016	,	2	,'digital',	156	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	80	,	40	,	2018	,	4	,'home appliances',	371	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	81	,	70	,	2015	,	4	,'home appliances',	661	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	82	,	111	,	2018	,	3	,'sports items',	461	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	83	,	182	,	2015	,	1	,'electronics',	797	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	84	,	61	,	2018	,	2	,'digital',	708	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	85	,	22	,	2018	,	2	,'digital',	792	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	86	,	217	,	2018	,	3	,'sports items',	687	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	87	,	86	,	2019	,	1	,'electronics',	180	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	88	,	218	,	2019	,	2	,'digital',	833	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	89	,	14	,	2019	,	3	,'sports items',	215	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	90	,	80	,	2019	,	4	,'home appliances',	499	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	91	,	47	,	2018	,	2	,'digital',	85	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	92	,	88	,	2017	,	3	,'sports items',	453	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	93	,	172	,	2017	,	2	,'digital',	212	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	94	,	107	,	2019	,	1	,'electronics',	362	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	95	,	88	,	2019	,	1	,'electronics',	873	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	96	,	179	,	2015	,	2	,'digital',	87	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	97	,	84	,	2016	,	2	,'digital',	831	);
INSERT INTO [dbo].[Sales_Details] ([Invoice_id] ,[Cust_id] ,[Year] ,[Product_id] ,[Product] ,[Sales])   VALUES (	98	,	188	,	2015	,	4	,'home appliances',	634	);

select * from Sales_Details
-- Insert data for the year 2020

INSERT INTO Sales_Details (Invoice_id, Cust_id, Year, Product_id, Product, Sales)
VALUES
(100, 101, 2020, 10, 'Laptop', 800.00),
(101, 102, 2020, 11, 'Tablet', 300.00),
(102, 103, 2020, 12, 'Smartphone', 600.00),
(103, 104, 2020, 10, 'Laptop', 850.00),
(104, 105, 2020, 11, 'Tablet', 350.00),
(105, 106, 2020, 12, 'Smartphone', 620.00),
(106, 107, 2020, 10, 'Laptop', 900.00),
(107, 108, 2020, 11, 'Tablet', 380.00),
(108, 109, 2020, 12, 'Smartphone', 640.00),
(109, 110, 2020, 10, 'Laptop', 950.00),
(110, 111, 2020, 11, 'Tablet', 400.00),
(111, 112, 2020, 12, 'Smartphone', 660.00),
(112, 113, 2020, 10, 'Laptop', 980.00),
(113, 114, 2020, 11, 'Tablet', 420.00),
(114, 115, 2020, 12, 'Smartphone', 690.00);

-- Insert data for the year 2021
INSERT INTO Sales_Details (Invoice_id, Cust_id, Year, Product_id, Product, Sales)
VALUES
(115, 101, 2021, 10, 'Laptop', 810.00),
(116, 102, 2021, 11, 'Tablet', 310.00),
(117, 103, 2021, 12, 'Smartphone', 605.00),
(118, 104, 2021, 10, 'Laptop', 855.00),
(119, 105, 2021, 11, 'Tablet', 355.00),
(120, 106, 2021, 12, 'Smartphone', 625.00),
(121, 107, 2021, 10, 'Laptop', 905.00),
(122, 108, 2021, 11, 'Tablet', 385.00),
(123, 109, 2021, 12, 'Smartphone', 645.00),
(124, 110, 2021, 10, 'Laptop', 955.00),
(125, 111, 2021, 11, 'Tablet', 405.00),
(126, 112, 2021, 12, 'Smartphone', 665.00),
(127, 113, 2021, 10, 'Laptop', 985.00),
(128, 114, 2021, 11, 'Tablet', 425.00),
(129, 115, 2021, 12, 'Smartphone', 695.00);


-- Insert data for the year 2022
INSERT INTO Sales_Details (Invoice_id, Cust_id, Year, Product_id, Product, Sales)
VALUES
(130, 101, 2022, 10, 'Laptop', 820.00),
(131, 102, 2022, 11, 'Tablet', 330.00),
(132, 103, 2022, 12, 'Smartphone', 620.00),
(133, 104, 2022, 10, 'Laptop', 860.00),
(134, 105, 2022, 11, 'Tablet', 360.00),
(135, 106, 2022, 12, 'Smartphone', 630.00),
(136, 107, 2022, 10, 'Laptop', 910.00),
(137, 108, 2022, 11, 'Tablet', 390.00),
(138, 109, 2022, 12, 'Smartphone', 650.00),
(139, 110, 2022, 10, 'Laptop', 960.00),
(140, 111, 2022, 11, 'Tablet', 410.00),
(141, 112, 2022, 12, 'Smartphone', 670.00),
(142, 113, 2022, 10, 'Laptop', 990.00),
(143, 114, 2022, 11, 'Tablet', 430.00),
(144, 115, 2022, 12, 'Smartphone', 690.00);

-- Insert data for the year 2023
INSERT INTO Sales_Details (Invoice_id, Cust_id, Year, Product_id, Product, Sales)
VALUES
(145, 101, 2023, 10, 'Laptop', 830.00),
(146, 102, 2023, 11, 'Tablet', 340.00),
(147, 103, 2023, 12, 'Smartphone', 635.00),
(148, 104, 2023, 10, 'Laptop', 870.00),
(149, 105, 2023, 11, 'Tablet', 370.00),
(150, 106, 2023, 12, 'Smartphone', 645.00),
(151, 107, 2023, 10, 'Laptop', 920.00),
(152, 108, 2023, 11, 'Tablet', 395.00),
(153, 109, 2023, 12, 'Smartphone', 660.00),
(154, 110, 2023, 10, 'Laptop', 970.00),
(155, 111, 2023, 11, 'Tablet', 420.00),
(156, 112, 2023, 12, 'Smartphone', 675.00),
(157, 113, 2023, 10, 'Laptop', 995.00),
(158, 114, 2023, 11, 'Tablet', 440.00),
(159, 115, 2023, 12, 'Smartphone', 695.00);

-- Insert data for the year 2024
INSERT INTO Sales_Details (Invoice_id, Cust_id, Year, Product_id, Product, Sales)
VALUES
(160, 101, 2024, 10, 'Laptop', 840.00),
(161, 102, 2024, 11, 'Tablet', 350.00),
(162, 103, 2024, 12, 'Smartphone', 645.00),
(163, 104, 2024, 10, 'Laptop', 880.00),
(164, 105, 2024, 11, 'Tablet', 380.00),
(165, 106, 2024, 12, 'Smartphone', 660.00),
(166, 107, 2024, 10, 'Laptop', 930.00),
(167, 108, 2024, 11, 'Tablet', 405.00),
(168, 109, 2024, 12, 'Smartphone', 670.00),
(169, 110, 2024, 10, 'Laptop', 980.00),
(170, 111, 2024, 11, 'Tablet', 430.00),
(171, 112, 2024, 12, 'Smartphone', 685.00),
(172, 113, 2024, 10, 'Laptop', 998.00),
(173, 114, 2024, 11, 'Tablet', 445.00),
(174, 115, 2024, 12, 'Smartphone', 695.00);
go



-- Insert data for the year 2025
INSERT INTO Sales_Details (Invoice_id, Cust_id, Year, Product_id, Product, Sales)
VALUES
(175, 116, 2025, 10, 'Laptop', 1020.00),
(176, 117, 2025, 11, 'Tablet', 460.00),
(177, 118, 2025, 12, 'Smartphone', 710.00),
(178, 119, 2025, 10, 'Laptop', 1055.00),
(179, 120, 2025, 11, 'Tablet', 480.00),
(180, 121, 2025, 12, 'Smartphone', 730.00),
(181, 122, 2025, 10, 'Laptop', 1080.00),
(182, 123, 2025, 11, 'Tablet', 495.00),
(183, 124, 2025, 12, 'Smartphone', 750.00),
(184, 125, 2025, 10, 'Laptop', 1105.00),
(185, 126, 2025, 11, 'Tablet', 510.00),
(186, 127, 2025, 12, 'Smartphone', 765.00),
(187, 128, 2025, 10, 'Laptop', 1120.00),
(188, 129, 2025, 11, 'Tablet', 525.00),
(189, 130, 2025, 12, 'Smartphone', 780.00);

go

select * from Sales_Details where year =2020;


CREATE PROCEDURE listsalesyear	
AS
BEGIN
	
	SET NOCOUNT ON;
	select distinct Year from Sales_Details
	where Year>=2016

END
GO


CREATE PROCEDURE salesineachyear
@Per_year int
AS
BEGIN
	
	SET NOCOUNT ON;
	SELECT *   from Sales_Details where Year =  @Per_year;
END
GO